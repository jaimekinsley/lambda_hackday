exports.handler = () => {
  console.log('hello i am a lambda with zip upload');
};
